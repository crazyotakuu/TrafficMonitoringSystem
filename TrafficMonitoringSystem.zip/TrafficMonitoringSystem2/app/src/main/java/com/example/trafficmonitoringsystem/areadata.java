package com.example.trafficmonitoringsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

public class areadata extends AppCompatActivity implements View.OnClickListener {
    EditText et1,et2,et3,et4;
    Button b1;
    String url;
    int result;
    URL finalurl;
    public static String username;
    String password,fname,lname;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_areadata);
        et1=findViewById(R.id.editText);
        et2=findViewById(R.id.editText2);
        et3=findViewById(R.id.editText3);
        et4=findViewById(R.id.editText8);
        b1=findViewById(R.id.button);
        b1.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        username = et1.getText().toString();
        password = et2.getText().toString();
        fname= et3.getText().toString();
        lname=et4.getText().toString();
        new areadata.getresponse().execute();
    }
    private class getresponse extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... voids) {

            url ="http://10.12.80.61/tmsareadata.php?user="+areadata.username+"&pass=" + password+"&name="+fname+
                    "&age="+lname;
            Log.v("url", url);
            try {
                finalurl = new URL(url);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet();
            try {
                request.setURI(new URI(url));
            } catch (URISyntaxException e) {
                e.printStackTrace();
            }
            HttpResponse response = null;
            try {
                response = client.execute(request);
            } catch (IOException e) {
                e.printStackTrace();
            }
            BufferedReader in = null;
            try {
                in = new BufferedReader(new
                        InputStreamReader(response.getEntity().getContent()));
            } catch (IOException e) {
                e.printStackTrace();
            }

            StringBuffer sb = new StringBuffer("");
            String line = "";

            while (true) {
                try {
                    if (!((line = in.readLine()) != null)) break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
                sb.append(line);
                break;
            }

            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            result = Integer.parseInt(sb.toString());
            Log.v("Message", sb.toString());
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            //t.setText(m);
            if (result == 1) {
                Toast.makeText(areadata.this, "Succesfully added record", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(areadata.this, admin.class);
                startActivity(intent);
            } else {
                Toast.makeText(areadata.this, "some error has occured", Toast.LENGTH_SHORT).show();
            }
            super.onPostExecute(aVoid);
        }

    }
}
