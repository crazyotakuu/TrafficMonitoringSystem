package com.example.trafficmonitoringsystem;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Arrays;

public class user extends AppCompatActivity implements View.OnClickListener {
    TextView tv;
    EditText et1, et2;
    String src, dest,s="";
    Button b1, b3,b2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
        tv = findViewById(R.id.textView2);
        SharedPreferences sp =
                getSharedPreferences
                        ("mycredentials",
                                Context.MODE_PRIVATE);
        String name = sp.getString
                ("name", "NA");
        tv.setText("Welcome " + name);
        et1 = findViewById(R.id.editTextusersrc);
        et2 = findViewById(R.id.editTextuserdest);
        b1 = findViewById(R.id.button3);
        b2=findViewById(R.id.button5);
        b2.setOnClickListener(this);
        b3 = findViewById(R.id.button2);
        b1.setOnClickListener(this);
        b3.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {
        if (v == b1) {

            Vertex v1 = new Vertex("thudiyalur");
            Vertex v2 = new Vertex("coimbatorenorth");
            Vertex v3=  new Vertex("vellakinar");
            Vertex v4 = new Vertex("urumandapalayam");
            Vertex v5 = new Vertex("nachipalayam");
            Vertex v6 = new Vertex("nehrunagar");
            Vertex v7 = new Vertex("venkatasamynagar");
            Vertex v8 = new Vertex("subramaniyanagar");
            Vertex v9 = new Vertex("saravanampatti");

            v1.addNeighbour(new Edge(2.4, v1, v2));
            v1.addNeighbour(new Edge(2.1, v1, v3));

            v3.addNeighbour(new Edge(5.7, v3, v9));
            v3.addNeighbour(new Edge(1.9, v3, v4));

            v4.addNeighbour(new Edge(2.7, v4, v5));

            v5.addNeighbour(new Edge(2.4, v5, v8));
            v5.addNeighbour(new Edge(3.5, v4, v6));

            v6.addNeighbour(new Edge(2.5, v6, v7));


            Dijkstra dijkstra = new Dijkstra();
            AlertDialog.Builder a2 =
                    new AlertDialog.Builder(
                            user.this);
            a2.setTitle("PATH");
            src=et1.getText().toString();
            switch(src) {
                case "thudiyalur":
                    dijkstra.computePath(v1);
                    break;

                case "coimbatorenorth":
                    dijkstra.computePath(v2);
                    break;

                case "vellakinar":
                    dijkstra.computePath(v3);
                    break;

                case "urumandapalayam":
                    dijkstra.computePath(v4);
                    break;

                case "nachipalayam":
                    dijkstra.computePath(v5);
                    break;

                case "nehrunagar":
                    dijkstra.computePath(v6);
                    break;

                case "venkatasamynagar":
                    dijkstra.computePath(v7);
                    break;

                case "subramaniyanagar":
                    dijkstra.computePath(v8);
                    break;

                case "saravanampatti":
                    dijkstra.computePath(v9);
                    break;
            }
            dest=et2.getText().toString();
            switch(dest)
            {
                case "thudiyalur":
                     s =(dijkstra.getShortestPathTo(v1));
                    a2.setMessage(s);
                    break;

                case "coimbatorenorth":
                     s =(dijkstra.getShortestPathTo(v2));
                    a2.setMessage(s);
                    break;

                case "vellakinar":
                     s =(dijkstra.getShortestPathTo(v3));
                    Toast.makeText(this,s, Toast.LENGTH_LONG).show();

                    break;

                case "urumandapalayam":
                    s=(dijkstra.getShortestPathTo(v4));
                    a2.setMessage(s);
                    break;

                case "nachipalayam":
                    s= (dijkstra.getShortestPathTo(v5));
                    a2.setMessage(s);
                    break;

                case "nehrunagar":
                     s =(dijkstra.getShortestPathTo(v6));
                    a2.setMessage(s);
                    break;

                case "venkatasamynagar":
                     s =(dijkstra.getShortestPathTo(v7));
                    a2.setMessage(s);
                    break;

                case "subramaniyanagar":
                    s =(dijkstra.getShortestPathTo(v8));
                    a2.setMessage(s);
                    break;

                case "saravanampatti":
                    s =(dijkstra.getShortestPathTo(v9));
                    a2.setMessage(s);
                    break;
            }

            a2.setMessage(s);
            a2.setCancelable(true);
            a2.show();
           // populateTable();
        }else if(v==b3){
                int i=20;
                i=i+3;
                AlertDialog.Builder a2 =
                        new AlertDialog.Builder(
                                user.this);
                a2.setTitle("ESTIMATED TIME");
                a2.setMessage("EST-"+i+"min");
                a2.setCancelable(true);
                a2.show();



        }else if(v==b2){
            Intent i=new Intent(this,MainActivity.class);
            startActivity(i);
        }

    }



}

