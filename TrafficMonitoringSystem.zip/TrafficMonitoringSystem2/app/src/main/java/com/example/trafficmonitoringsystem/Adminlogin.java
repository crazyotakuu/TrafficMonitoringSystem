package com.example.trafficmonitoringsystem;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Adminlogin extends AppCompatActivity implements View.OnClickListener {
    EditText et1,et2;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adminlogin);
        et1=findViewById(R.id.username);
        et2=findViewById(R.id.passwordadmin);
        b1=findViewById(R.id.loginadmin);
        b1.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v==b1){
        String s1=et1.getText().toString();
        String s2=et2.getText().toString();
        if(s1.equals("admin")&&s2.equals("admin")){
            Toast.makeText(this,"Sucessful Log in",Toast.LENGTH_SHORT).show();
            Intent i=new Intent(this,admin.class);
            startActivity(i);
        }else{
            AlertDialog.Builder a2 =
                    new AlertDialog.Builder(
                            Adminlogin.this);
            a2.setTitle("ERROR");
            a2.setMessage("PLEASE ENTER THE CORRECT CREDENTIALS");
            a2.setCancelable(true);
            a2.show();
            et1.setText("");
            et2.setText("");
        }}

    }
}
