package com.example.trafficmonitoringsystem;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button b1,b2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.user);
        b2=findViewById(R.id.police);
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
    }
    public boolean onCreateOptionsMenu
            (Menu menu) {
        getMenuInflater().inflate
                (R.menu.menu, menu);

        return true;
    }
    public boolean onOptionsItemSelected
            (MenuItem item) {
        switch(item.getItemId())
        {
            case R.id.i1:

                Intent i=new Intent(this,Adminlogin.class);
                startActivity(i);
                break;

            case R.id.i3:
                AlertDialog.Builder al =
                        new AlertDialog.Builder(
                                MainActivity.this);
                al.setTitle("Traffic Monitoring System");
                al.setMessage("The chief motive of this project is to create an efficient application for monitoring traffic");
                al.setCancelable(true);
                al.show();

                break;

            case R.id.i2:
                AlertDialog.Builder a2 =
                        new AlertDialog.Builder(
                                MainActivity.this);
                a2.setTitle("Team");
                a2.setMessage("M.Uday Srinivas-CB.EN.U4CSE17637"+"\n"+"P.Lokesh Reddy-CB.EN.U4CSE17646"
                +"\n"+"R.Swaroop-CB.EN.U4CSE17653"+"\n"+"Vaddi Teja-CB.EN.U4CSE17666");
                a2.setCancelable(true);
                a2.show();


                break;
        }


        return true;
    }




    @Override
    public void onClick(View v) {
        if(b1==v){
            Intent i= new Intent(this,UserLogin.class);
            startActivity(i);

        }else if(b2==v){
            Intent i1= new Intent(this,Policelogin.class);
            startActivity(i1);
        }
    }
}
