package com.example.trafficmonitoringsystem;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;

public class usersignup extends AppCompatActivity implements View.OnClickListener {

    EditText et1,et2,et3,et4,et5,et6,et7;
    Button b1;
    String url;
    URL finalurl;
    int fine=0;
    int result;
    public static String username;
    String password,fname,lname,vno,lno,vname;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usersignup);
        et1=findViewById(R.id.editText);
        et2=findViewById(R.id.editText2);
        et3=findViewById(R.id.editText3);
        et4=findViewById(R.id.editText4);
        et5=findViewById(R.id.editText5);
        et6=findViewById(R.id.editText6);
        et7=findViewById(R.id.editText7);
        b1=findViewById(R.id.button);
        b1.setOnClickListener(this);
    }

    public void onClick(View view) {
         if(view==b1){
            username = et1.getText().toString();
            password = et2.getText().toString();
            fname= et3.getText().toString();
            lname=et4.getText().toString();
            vno=et5.getText().toString();
            lno=et6.getText().toString();
            vname=et7.getText().toString();
             new usersignup.getresponse().execute();

        }
    }
    private class getresponse extends AsyncTask<Void, Void, Void> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... voids) {

            url ="http://10.12.80.61/tmsusersignup.php?user="+usersignup.username+"&pass=" + password+"&name="+fname+
            "&age="+lname+"&email="+fine+"&phone="+vno+"&lno="+lno+"&vname="+vname;
            Log.v("url", url);
            try {
                finalurl = new URL(url);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            HttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet();
            try {
                request.setURI(new URI(url));
            } catch (URISyntaxException e) {
                e.printStackTrace();
            }
            HttpResponse response = null;
            try {
                response = client.execute(request);
            } catch (IOException e) {
                e.printStackTrace();
            }
            BufferedReader in = null;
            try {
                in = new BufferedReader(new
                        InputStreamReader(response.getEntity().getContent()));
            } catch (IOException e) {
                e.printStackTrace();
            }

            StringBuffer sb = new StringBuffer("");
            String line = "";

            while (true) {
                try {
                    if (!((line = in.readLine()) != null)) break;
                } catch (IOException e) {
                    e.printStackTrace();
                }
                sb.append(line);
                break;
            }

            try {
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            result = Integer.parseInt(sb.toString());
            Log.v("Message", sb.toString());
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            //t.setText(m);
            if (result == 1) {
                Toast.makeText(usersignup.this, "Succesful sign up", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(usersignup.this, UserLogin.class);
                startActivity(intent);
            } else {
                Toast.makeText(usersignup.this, "some error has occured", Toast.LENGTH_SHORT).show();
            }
            super.onPostExecute(aVoid);
        }

    }

}
